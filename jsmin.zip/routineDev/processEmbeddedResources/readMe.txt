1. Open directory that contains resources.
2. Alt+D to enter address bar. 
3. Type powershell to open in current directory. 

-If necessary, allow running scripts with <Set-ExecutionPolicy RemoteSigned -force>
-You will need to run powershell as administrator to do this.

-----------------------
Running Windows PowerShell Scripts 
http://technet.microsoft.com/en-us/library/ee176949.aspx
-----------------------
Make sure you�ve changed your execution policy.

To run a script, specify the entire file path, or either: 
	1) use the .\ notation to run a script in the current directory or 
	2) put the folder where the script resides in your Windows path.

If your file path includes blank spaces,
enclose the path in double quote marks and preface the path with an ampersand.
-----------------------

-----------------------
Minifying with Powershell
-----------------------
http://minifyps.codeplex.com/
