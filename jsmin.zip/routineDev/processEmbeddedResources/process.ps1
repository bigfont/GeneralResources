cd "C:\Users\Shaun\Desktop\routineDev\processEmbeddedResources"

#import dependencies
Import-Module (".\minJS");

#change to the assets folder
cd ..
$Assetsfolder = Get-ChildItem -Directory | Where-Object { $_.Name -match 'assets' }
cd $Assetsfolder;

<#
TODO
Create the css directory if it doesn't exist.
In the meantime, just create it manually.
#>

@'
------------------
process lesscss
------------------
'@
$files_less = Get-ChildItem -recurse -include *.less | Where-Object { 'bootstrap', 'responsive' -contains $_.BaseName }
foreach ($file in $files_less)
{       
    $savePath = $file.FullName -replace "less", "css"
    lessc $file.FullName > $savePath;
    #print results
    '-' + $savePath;
}

@'
------------------
process js
------------------
'@
$files_js = Get-ChildItem -recurse -include *.js -Exclude *.min.js
foreach ($file in $files_js)
{           
    $str = Get-Content -Path $file.FullName;
    $min = (minify -inputData $str -inputDataType "js");    
    $savePath = ($file.FullName -replace "`\.js", '.min.js');    
    $min | Out-File $savePath;
    #print results
    '-' + $savePath;
}
