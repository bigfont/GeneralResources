!function ($) {
    $(function () {

        // initialize the carousel
        $('#myCarousel').carousel();
    })
}(window.jQuery)